# Astronomy Hub — Approved Visual Reference Pack

The owner approved the cinematic design family for the Solar System, Earth and Sky views.

Use the original PNGs as visual-direction references alongside the pre-existing R1-A Adaptive Explorer and ORA-6 sketches. The **solar-primary-cinematic** reference has priority as the flagship scene. Do not replace the accepted design with another generic dashboard.

Scope of approval: cinematic composition, scene-first hierarchy, restrained glass UI, contextual object details, clear direct search, navigation, and visual ambition.

Not yet approved/verified: exact pixel geometry, mobile adaptation, astrophysical facts shown in these artistic illustrations, licensed real-world surface imagery, 3D assets, per-frame performance, and a final implementation.

All UI text/measurements and scene art must be backed by real data or labeled illustrative in the product. Retain all repository scientific and licensing controls.

See manifest.json for per-image SHA-256.
